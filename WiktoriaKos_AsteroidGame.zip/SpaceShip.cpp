#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/rotate_vector.hpp>
#include "SpaceShip.hpp"
#include "Asteroid.hpp"
#include "sre/Renderer.hpp"
#include "AsteroidsGame.hpp"

SpaceShip::SpaceShip(const sre::Sprite& sprite, AsteroidsGame* game) : GameObject(sprite), ptr_AsteroidGame(game)
{
    scale = glm::vec2(0.5f,0.5f);
    winSize = sre::Renderer::instance->getDrawableSize();
    radius = 23;
    position = winSize * 0.5f;
    velocity = glm::vec2(0.0f,0.0f);
    glm::vec2 directionL;
}
SpaceShip::SpaceShip(const sre::Sprite& sprite, AsteroidsGame* game, glm::vec2 pos) : GameObject(sprite), ptr_AsteroidGame(game)
{
    scale = glm::vec2(0.5f, 0.5f);
    winSize = sre::Renderer::instance->getDrawableSize();
    radius = 23;
    position = pos;
    velocity = glm::vec2(0.0f, 0.0f);
    glm::vec2 directionL;
}

void SpaceShip::update(float deltaTime) {
    directionL = glm::rotateZ(glm::vec3(0, 450, 0), glm::radians(rotation));
    if (thrust){
        float acceleration = deltaTime*thrustPower;
        glm::vec2 direction = glm::rotateZ(glm::vec3(0,acceleration,0), glm::radians(rotation));
        velocity += direction;
        float speed = glm::length(velocity);
        if (speed > maxSpeed){
            velocity = velocity * (maxSpeed / speed);
        }
    } else {
        velocity = velocity * (1.0f - drag*deltaTime);
    }
    position += velocity * deltaTime;
    if (rotateCCW){
        rotation += deltaTime * rotationSpeed;
    }
    if (rotateCW){
        rotation -= deltaTime * rotationSpeed;
    }

    if (fire) {
        ptr_AsteroidGame->FireLaser(this->position, this->rotation, this->directionL);
        fire = false;
    }

    // wrap around
    if (position.x < 0){
        position.x += winSize.x;
    } else if (position.x > winSize.x){
        position.x -= winSize.x;
    }
    if (position.y < 0){
        position.y += winSize.y;
    } else if (position.y > winSize.y){
        position.y -= winSize.y;
    }
}

void SpaceShip::onCollision(std::shared_ptr<GameObject> other) {
    if (std::dynamic_pointer_cast<Asteroid>(other) != nullptr)
    {
        //collision with an asteroid
        ptr_AsteroidGame->DestroyShip(this,position);
    }
}

void SpaceShip::onKey(SDL_Event &keyEvent) {
    if (keyEvent.key.keysym.sym == SDLK_UP){
        thrust = keyEvent.type == SDL_KEYDOWN;
    }
    if (keyEvent.key.keysym.sym == SDLK_LEFT){
        rotateCCW = keyEvent.type == SDL_KEYDOWN;
    }
    if (keyEvent.key.keysym.sym == SDLK_RIGHT){
        rotateCW = keyEvent.type == SDL_KEYDOWN;
    }
    if (keyEvent.key.keysym.sym == SDLK_SPACE) {
        fire = keyEvent.type == SDL_KEYDOWN;
    }

}

