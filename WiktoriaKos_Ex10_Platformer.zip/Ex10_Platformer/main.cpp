#include "PlatformerGame.hpp"

int main(){
   new PlatformerGame();
   return 0;
}